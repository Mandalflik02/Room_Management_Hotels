from .logs import *
from .logs_levels import *

setup_logging_system()
print("||||||||||||||| Logging system is ready to go |||||||||||||||")
